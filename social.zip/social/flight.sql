-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 18, 2021 at 09:29 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `flight`
--

-- --------------------------------------------------------

--
-- Table structure for table `flight`
--

CREATE TABLE `flight` (
  `CustomerID` int(11) NOT NULL,
  `CustomerName` varchar(250) NOT NULL,
  `Origin_City` varchar(30) NOT NULL,
  `destination_City` varchar(250) NOT NULL,
  `Depature_date` date NOT NULL,
  `Return_date` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `flight`
--

INSERT INTO `flight` (`CustomerID`, `CustomerName`, `Origin_City`, `destination_City`, `Depature_date`, `Return_date`) VALUES
(1, 'Maria Anders', 'Pune', 'Delhi', '2014-03-16', '2014-03-17'),
(2, 'Ana Trujillo', 'Banglore', 'Landon', '2021-03-16', '2021-03-17'),
(3, 'Antonio Moreno', 'Paris', 'Newyork', '2021-08-02', '2021-08-03'),
(4, 'Thomas Hardy', 'Bandra', 'Mumbai', '2021-11-11', '2021-11-12'),
(5, 'Paula Parente', 'varca', 'Delhi', '2021-08-02', '2021-08-03'),
(6, 'Wolski Zbyszek', 'Pune', 'Lacknow', '2021-08-02', '2021-08-02'),
(7, 'Matti Karttunen', 'Uttarpradesh', 'Delhi', '2021-03-16', '2021-03-17'),
(8, 'Karl Jablonski', 'Goa', 'Mumbai', '2021-04-18', '2021-04-19'),
(9, 'Paula Parente', 'Gujarat', 'Landon', '2021-03-10', '2021-03-11'),
(10, 'John Koskitalo', 'Shirdi', 'Pune', '2021-02-02', '2021-02-03');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `flight`
--
ALTER TABLE `flight`
  ADD PRIMARY KEY (`CustomerID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `flight`
--
ALTER TABLE `flight`
  MODIFY `CustomerID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=146;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
