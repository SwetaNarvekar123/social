<?php

$db = mysqli_connect("localhost","root","","flight");

if(!$db)
{
    die("Connection failed: " . mysqli_connect_error());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<!-- Meta -->
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta content="Anil z" name="author">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Flight Booking System</title>
<link rel="stylesheet" href="style.css">
</head>
<body>
<section class="bg">
	<div class="container">
    	<div class="row">
        	<div class="col-sm-12 col-lg-12 text-center">
            		<h1 class="text-white">Flight Search Engine</h1>
                </div>
            </div>
        </div>
    </div>
</section>
<section>
	<div class="container-fluid">
    	<div class="row">
        	<div class="col-lg-9" style="padding-top:30px;">
            	<div class="row">
                    <div class="col-md-12">
                        <div style="box-shadow: 0px 2px 10px #c3c1c1;">
                                  <table class="table-responsive-sm" id="customers">
                                     <thead>
                                       <tr>
                                        <th>Origin City</th>
                                        <th>Destination City</th>
                                        <th>Departure Date</th>
                                        <th>Return Date</th>
                                        <th>Passangers</th>
                                        <th>Bookings</th>
                                        </tr>
                                      </thead>
                                     <tbody>
                                   </tbody>
                               </table>
                            </div>
                        </div>
                    </div>
                </div>
            <div class="col-lg-3 order-lg-first" style="padding-top:30px;">
            	<div style="border: 1px solid #000;padding: 20px;box-shadow: 0px 2px 10px #c3c1c1;">
                    <button class="tablink btn btn-primary" onclick="openPage('Home', this, 'red')" id="defaultOpen">One Way</button>
                    <button class="tablink btn btn-primary" onclick="openPage('News', this, 'green')" >Return</button>
                    <div id="News" class="tabcontent">
                      <div>
                           <br>
                                <form>
                                    <select id="tags4" class="form-control">
                                       <option  selected>Return Date</option>
                                           <?php
                                            $records = mysqli_query($db, "SELECT Return_date From flight");  
                                             while($data = mysqli_fetch_array($records))
                                                {echo "<option value='". $data['Return_date'] ."'>" .$data['Return_date'] ."</option>";
                                                }
                                            ?>  
                                       </select>
                                   </form>
                              </div>
                         </div>
<div id="Home" class="tabcontent">
     <form method="post" style="padding-top:50px;">
                        <div class="row">
                            <div class="form-group col-lg-12">
                                <input type="text" id="tags" class="form-control"  placeholder="Enter Origin city" />
                             </div>
                            <div class="form-group col-lg-12">
                                <input type="text" id="tags1" class="form-control"  placeholder="Enter Destination city" />
                             </div>
                            <div class="form-group col-md-12">
                                     <select id="tags3" class="form-control">
                                            <option selected>Depature Date</option>
                                            <?php
                                                $records = mysqli_query($db, "SELECT Depature_date From flight");  
                                                 while($data = mysqli_fetch_array($records)){
                                                 echo "<option value='". $data['Depature_date'] ."'>" .$data['Depature_date'] ."</option>";} ?> 
                                    </select>
                            </div>
                            
                              <div class="form-group col-md-12">
                                   <select id="tags4" class="form-control">
                                   <option  selected>Return Date</option>
    <?php
        $records = mysqli_query($db, "SELECT Return_date From flight");  

        while($data = mysqli_fetch_array($records))
        {
            echo "<option value='". $data['Return_date'] ."'>" .$data['Return_date'] ."</option>";  
        } 
        
    ?>  
  </select>
</div>
                               <div class="form-group col-md-12">
                                    <select id="tags5" class="form-control">
                                    <option selected>Passangers</option>
    <?php
        $records = mysqli_query($db, "SELECT CustomerName From flight");  

        while($data = mysqli_fetch_array($records))
        {
            echo "<option value='". $data['CustomerName'] ."'>" .$data['CustomerName'] ."</option>";  
        } 
        
    ?>  
  </select>
</div>
                            <div class="col-lg-12">
                                <button type="button" name="search" class="btn btn-primary" id="search">Search</button>
                            </div>
                        </div>
                    </form>
                	</div>
                </div>
            </div>
        </div>
    </div>
</section>

<script src="jquery-3.3.1.js" type="text/javascript"></script>
<script>
  $(document).ready(function(){

    $("#txt_search").keyup(function(){
        var search = $(this).val();

        if(search != ""){

            $.ajax({
                url: 'getSearch.php',
                type: 'post',
                data: {search:search, type:1},
                dataType: 'json',
                success:function(response){
                
                    var len = response.length;
                    $("#searchResult").empty();
                    for( var i = 0; i<len; i++){
                        var id = response[i]['id'];
                        var name = response[i]['name'];

                        $("#searchResult").append("<li value='"+id+"'>"+name+"</li>");

                    }

                    // binding click event to li
                    $("#searchResult li").bind("click",function(){
                        setText(this);
                    });

                }
            });
        }

    });

    $("#txt_search1").keyup(function(){
        var search = $(this).val();

        if(search != ""){

            $.ajax({
                url: 'getSearch.php',
                type: 'post',
                data: {search:search, type:1},
                dataType: 'json',
                success:function(response){
                
                    var len = response.length;
                    $("#searchResult").empty();
                    for( var i = 0; i<len; i++){
                        var id = response[i]['id'];
                        var name = response[i]['name'];

                        $("#searchResult").append("<li value='"+id+"'>"+name+"</li>");

                    }

                    // binding click event to li
                    $("#searchResult li").bind("click",function(){
                        setText(this);
                    });

                }
            });
        }

    });

});


function setText(element){

    var value = $(element).text();
    var userid = $(element).val();

    $("#txt_search").val(value);
    $("#txt_search").val(value);
    $("#searchResult").empty();
    
    // Request User Details
    $.ajax({
        url: 'getSearch.php',
        type: 'post',
        data: {userid:userid, type:2},
        dataType: 'json',
        success: function(response){

            var len = response.length;
            $("#userDetail").empty();
            if(len > 0){
                var username = response[0]['username'];
                var email = response[0]['email'];
                $("#userDetail").append("Username : " + username + "<br/>");
                $("#userDetail").append("Email : " + email);
            }
        }

    });
}
</script>
<script>
function openPage(pageName,elmnt,color) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }
  document.getElementById(pageName).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>
   <script>
$(document).ready(function(){
 
 load_data();

 function load_data(query)
 {
  $.ajax({
   url:"fetch.php",
   method:"POST",
   data:{query:query},
   dataType:"json",
   success:function(data)
   {
    $('#total_records').text(data.length);
    var html = '';
    if(data.length > 0)
    {
     for(var count = 0; count < data.length; count++)
     {
      html += '<tr>';
     
      html += '<td><h5>'+data[count].Origin_City+'</h5></td>';
      html += '<td><h5>'+data[count].destination_City+'</h5></td>';
       html += '<td><h6>'+data[count].Depature_date+'</h6></td>';
      html += '<td><h6>'+data[count].Return_date+'</h6></td>';
             html += '<td><h6>'+data[count].CustomerName+'</h6></td>';
       html += '<td><div  style="width: 23%;height: 8px;"><img src="travelling.png"></div><div>Rs.9.500.00</div><br><div>Depart:10.00 AM</div><br><div>Arrive:12.00 PM</div><br><button type="button" name="search" class="btn btn-primary" id="search">Book This Flight</button></td></tr>';
     }
    }
    else
    {
     html = '<tr><td colspan="5">No Data Found</td></tr>';
    }
    $('tbody').html(html);
   }
  })
 }

 $('#search').click(function(){
  var query = $('#tagsr').val();
  load_data(query);
 });

});
</script>
<script>
function openPage(pageName,elmnt,color) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablink");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].style.backgroundColor = "";
  }
  document.getElementById(pageName).style.display = "block";
  elmnt.style.backgroundColor = color;
}

// Get the element with id="defaultOpen" and click on it
document.getElementById("defaultOpen").click();
</script>
   <script>
$(document).ready(function(){
 
 load_data();

 function load_data(query)
 {
  $.ajax({
   url:"fetch.php",
   method:"POST",
   data:{query:query},
   dataType:"json",
   success:function(data)
   {
    $('#total_records').text(data.length);
    var html = '';
    if(data.length > 0)
    {
     for(var count = 0; count < data.length; count++)
     {
      html += '<tr>';
     
      html += '<td><h5>'+data[count].Origin_City+'</h5></td>';
      html += '<td><h5>'+data[count].destination_City+'</h5></td>';
      html += '<td><h6>'+data[count].Depature_date+'</h6></td>';
      html += '<td><h6>'+data[count].Return_date+'</h6></td>';
             html += '<td><h6>'+data[count].CustomerName+'</h6></td>';
       html += '<td><div style="width: 23%;height: 8px;" class="mdisplay"><img src="travelling.png"></div><div>Rs.9.500.00</div><br><div>Depart:10.00 AM</div><br><div>Arrive:12.00 PM</div><br><button type="button" name="search" class="btn btn-primary" id="search">Book This Flight</button></td></tr>';
     }
    }
    else
    {
     html = '<tr><td colspan="5">No Data Found</td></tr>';
    }
    $('tbody').html(html);
   }
  })
 }

 $('#search').click(function(){
  var query = $('#tags').val();
  load_data(query);
 });

});
</script>
<script>
$(document).ready(function(){
 
 load_data();

 function load_data(query)
 {
  $.ajax({
   url:"fetch.php",
   method:"POST",
   data:{query:query},
   dataType:"json",
   success:function(data)
   {
    $('#total_records').text(data.length);
    var html = '';
    if(data.length > 0)
    {
     for(var count = 0; count < data.length; count++)
     {
       html += '<tr>';
     
      html += '<td><h5>'+data[count].Origin_City+'</h5></td>';
      html += '<td><h5>'+data[count].destination_City+'</h5></td>';
       html += '<td><h6>'+data[count].Depature_date+'</h6></td>';
      html += '<td><h6>'+data[count].Return_date+'</h6></td>';
    html += '<td><h6>'+data[count].CustomerName+'</h6></td>';
     html += '<td><div style="width: 23%;height: 8px;" class="mdisplay"><img src="travelling.png"></div><div>Rs.9.500.00</div><br><div>Depart:10.00 AM</div><br><div>Arrive:12.00 PM</div><br><button type="button" name="search" class="btn btn-primary" id="search">Book This Flight</button></td></tr>';
     }
    }
    else
    {
     html = '<tr><td colspan="5">No Data Found</td></tr>';
    }
    $('tbody').html(html);
   }
  })
 }

 $('#search').click(function(){
  var query = $('#tags3').val();
  load_data(query);
 });

});
</script>
<script>
$(document).ready(function(){
 
 load_data();

 function load_data(query)
 {
  $.ajax({
   url:"fetch.php",
   method:"POST",
   data:{query:query},
   dataType:"json",
   success:function(data)
   {
    $('#total_records').text(data.length);
    var html = '';
    if(data.length > 0)
    {
     for(var count = 0; count < data.length; count++)
     {
    html += '<tr>';
     
      html += '<td><h5>'+data[count].Origin_City+'</h5></td>';
      html += '<td><h5>'+data[count].destination_City+'</h5></td>';
      html += '<td><h6>'+data[count].Depature_date+'</h6></td>';
      html += '<td><h6>'+data[count].Return_date+'</h6></td>';
    html += '<td><h6>'+data[count].CustomerName+'</h6></td>';
       html += '<td><div style="width: 23%;height: 8px;" class="mdisplay"><img src="travelling.png"></div><div>Rs.9.500.00</div><br><div>Depart:10.00 AM</div><br><div>Arrive:12.00 PM</div><br><button type="button" name="search" class="btn btn-primary" id="search">Book This Flight</button></td></tr>';
     }
    }
    else
    {
     html = '<tr><td colspan="5">No Data Found</td></tr>';
    }
    $('tbody').html(html);
   }
  })
 }

 $('#search').click(function(){
  var query = $('#tags1').val();
  load_data(query);
 });

});
</script>
<script>
$(document).ready(function(){
 
 load_data();

 function load_data(query)
 {
  $.ajax({
   url:"fetch.php",
   method:"POST",
   data:{query:query},
   dataType:"json",
   success:function(data)
   {
    $('#total_records').text(data.length);
    var html = '';
    if(data.length > 0)
    {
     for(var count = 0; count < data.length; count++)
     {
      html += '<tr>';
     
      html += '<td><h5>'+data[count].Origin_City+'</h5></td>';
      html += '<td><h5>'+data[count].destination_City+'</h5></td>';
      html += '<td><h6>'+data[count].Depature_date+'</h6></td>';
      html += '<td><h6>'+data[count].Return_date+'</h6></td>';
     html += '<td><h6>'+data[count].CustomerName+'</h6></td>';
      html += '<td><div style="width: 23%;height: 8px;" class="mdisplay"><img src="travelling.png"></div><div>Rs.9.500.00</div><br><div>Depart:10.00 AM</div><br><div>Arrive:12.00 PM</div><br><button type="button" name="search" class="btn btn-primary" id="search">Book This Flight</button></td></tr>';
     }
    }
    else
    {
     html = '<tr><td colspan="5">No Data Found</td></tr>';
    }
    $('tbody').html(html);
   }
  })
 }

 $('#search').click(function(){
  var query = $('#tags4').val();
  load_data(query);
 });

});
</script>
<script>
$(document).ready(function(){
 
 load_data();

 function load_data(query)
 {
  $.ajax({
   url:"fetch.php",
   method:"POST",
   data:{query:query},
   dataType:"json",
   success:function(data)
   {
    $('#total_records').text(data.length);
    var html = '';
    if(data.length > 0)
    {
     for(var count = 0; count < data.length; count++)
     {
      
     
     html += '<tr>';
     
      html += '<td><h5>'+data[count].Origin_City+'</h5></td>';
      html += '<td><h5>'+data[count].destination_City+'</h5></td>';
      html += '<td><h6>'+data[count].Depature_date+'</h6></td>';
      html += '<td><h6>'+data[count].Return_date+'</h6></td>';
     html += '<td><h6>'+data[count].CustomerName+'</h6></td>';
      html += '<td><div style="width: 23%;height: 8px;" class="mdisplay"><img src="travelling.png"></div><div>Rs.9.500.00</div><br><div>Depart:10.00 AM</div><br><div>Arrive:12.00 PM</div><br><button type="button" name="search" class="btn btn-primary" id="search">Book This Flight</button></td></tr>';
     }
    }
    else
    {
     html = '<tr><td colspan="5">No Data Found</td></tr>';
    }
    $('tbody').html(html);
   }
  })
 }

 $('#search').click(function(){
  var query = $('#tags').val();
  load_data(query);
 });

});
</script>
<script>
$(document).ready(function(){
 
 load_data();

 function load_data(query)
 {
  $.ajax({
   url:"fetch.php",
   method:"POST",
   data:{query:query},
   dataType:"json",
   success:function(data)
   {
    $('#total_records').text(data.length);
    var html = '';
    if(data.length > 0)
    {
     for(var count = 0; count < data.length; count++)
     {
      html += '<tr>';
     
      html += '<td><h5>'+data[count].Origin_City+'</h5></td>';
      html += '<td><h5>'+data[count].destination_City+'</h5></td>';
      html += '<td><h6>'+data[count].Depature_date+'</h6></td>';
      html += '<td><h6>'+data[count].Return_date+'</h6></td>';
       html += '<td><h6>'+data[count].CustomerName+'</h6></td>';
       html += '<td><div style="width: 23%;height: 8px;" class="mdisplay"><img src="travelling.png"></div><div>Rs.9.500.00</div><br><div>Depart:10.00 AM</div><br><div>Arrive:12.00 PM</div><br><button type="button" name="search" class="btn btn-primary" id="search">Book This Flight</button></td></tr>';
     }
    }
    else
    {
     html = '<tr><td colspan="5">No Data Found</td></tr>';
    }
    $('tbody').html(html);
   }
  })
 }

 $('#search').click(function(){
  var query = $('#tags5').val();
  load_data(query);
 });

});
</script>
<script type="text/javascript" src="jquery.js"></script>
</body>
</html>