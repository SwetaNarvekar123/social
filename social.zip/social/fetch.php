<?php
$connect = new PDO("mysql:host=localhost;dbname=flight", "root", "");
$output = '';
$query = '';
if(isset($_POST["query"]))
{
 $search = str_replace(",", "|", $_POST["query"]);
 $query = "
 SELECT * FROM flight
 WHERE CustomerName REGEXP'".$search."' 
 OR  Origin_City REGEXP'".$search."' 
 OR destination_City REGEXP'".$search."' 
 OR Depature_date REGEXP '".$search."' 
 OR Return_date	 REGEXP '".$search."'
 ";
}
else
{
 $query = "
 SELECT * FROM flight ORDER BY CustomerID
 ";
}
$statement = $connect->prepare($query);
$statement->execute();
while($row = $statement->fetch(PDO::FETCH_ASSOC))
{
 $data[] = $row;
}
echo json_encode($data);
?>
